import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-readblog',
  templateUrl: 'readblog.html'
})
export class ReadblogPage {

  constructor(public navCtrl: NavController) {

  }

}
