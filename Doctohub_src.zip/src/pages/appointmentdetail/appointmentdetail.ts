import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-appointmentdetail',
  templateUrl: 'appointmentdetail.html'
})
export class AppointmentdetailPage {

  constructor(public navCtrl: NavController) {

  }

}
