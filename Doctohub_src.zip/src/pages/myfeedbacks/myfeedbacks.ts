import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-myfeedbacks',
  templateUrl: 'myfeedbacks.html'
})
export class MyfeedbacksPage {

  constructor(public navCtrl: NavController) {

  }

}
